const noActionAllert = function () {
    alertify.error('No se realizo ninguna accion');
};

const aceptOrNot = { labels: { ok: 'Aceptar', cancel: 'Cancelar' } };
