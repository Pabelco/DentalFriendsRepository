postFetch("/user", {}).then(data => { 
    console.log(data)
    alertify.success(data.message) 
}).catch(err => {
    alertify.success('Bienvenido usuario invitado') 
})